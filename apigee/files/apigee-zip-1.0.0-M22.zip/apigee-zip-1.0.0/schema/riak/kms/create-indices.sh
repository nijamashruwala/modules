#!/bin/bash
$1/search-cmd clear-schema-cache
$1/search-cmd uninstall api_products
$1/search-cmd uninstall apps
$1/search-cmd uninstall app_credentials
$1/search-cmd uninstall maps
$1/search-cmd uninstall oauth_10_access_tokens
$1/search-cmd uninstall oauth_10_request_tokens
$1/search-cmd uninstall oauth_10_verifiers
$1/search-cmd uninstall oauth_20_access_tokens
$1/search-cmd uninstall oauth_20_authorization_codes
$1/search-cmd install api_products
$1/search-cmd install apps
$1/search-cmd install app_credentials
$1/search-cmd install maps
$1/search-cmd install oauth_10_access_tokens
$1/search-cmd install oauth_10_request_tokens
$1/search-cmd install oauth_10_verifiers
$1/search-cmd install oauth_20_access_tokens
$1/search-cmd install oauth_20_authorization_codes
$1/search-cmd set-schema api_products $2/api_products.schema
$1/search-cmd set-schema app_credentials $2/app_credentials.schema
$1/search-cmd set-schema apps $2/apps.schema
$1/search-cmd set-schema maps $2/maps.schema
$1/search-cmd set-schema oauth_10_access_tokens $2/oauth_10_access_tokens.schema
$1/search-cmd set-schema oauth_10_request_tokens $2/oauth_10_request_tokens.schema
$1/search-cmd set-schema oauth_10_verifiers $2/oauth_10_verifiers.schema
$1/search-cmd set-schema oauth_20_access_tokens $2/oauth_20_access_tokens.schema
$1/search-cmd set-schema oauth_20_authorization_codes $2/oauth_20_authorization_codes.schema
