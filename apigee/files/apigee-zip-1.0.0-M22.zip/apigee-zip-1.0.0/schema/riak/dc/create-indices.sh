#!/bin/bash
$1/search-cmd uninstall developers
$1/search-cmd uninstall companies
$1/search-cmd uninstall company_developers
$1/search-cmd install developers
$1/search-cmd install companies
$1/search-cmd install company_developers
$1/search-cmd set-schema developers $2/developers.schema
$1/search-cmd set-schema companies $2/companies.schema
$1/search-cmd set-schema company_developers $2/company_developers.schema