 * Copyright (c) 2012, Apigee Corporation.  All rights reserved.
 * Apigee(TM) and the Apigee logo are trademarks or
 * registered trademarks of Apigee Corp. or its subsidiaries.  All other
 * trademarks are the property of their respective owners.


System Requirements
-------------------

JDK:
    1.6 or above

Disk:
    Apart from the space taken up by the distribution, the system logs are permitted
    to grow upto 100 MB. To change these settings see the logback.xml in conf/ directory.

Operating System:
    Platform independent, built and tested on CentOS 5.

Memory:
    The following is an estimate of how much memory should be allocated for the process:
        1 Organization with 1 proxy application: 100KB

Open Files:
    Ensure that the gateway process is permitted to open as many files as required. The
    following are the factors which influence this estimate:
      a. No of unique ports configured in virtual hosts (listening ports)
      b. No of concurrent connections that are possible to be made to external systems
            either as target endpoints or in java callout steps (client sockets)
      c. No of concurrent API calls that are in the system at any point of time (files)

    This is usually an OS specific setting. For example, on a CentOS 5.x instance, the following
    needs to be done to enable the process to open up files beyond the default limit (1024).
      a. Estimate the approximate number of files that may be needed
      b. If the number of required files is < 1024, no changes are needed
      c. Else, edit the file /etc/security/limits.conf and add the following lines (including the *):
           * soft nofile <estimated no of open files, say 10000>
           * hard nofile <estimated no of open files, say 10000>

Other Requirements
    To use HTTPS, ensure that openssl is installed on the system
    To enforce java scripts in the message flow, use Oracle JDK and not Open JDK.


Troubleshooting
----------------
All the system logs will be available at "logs/system.log" and the transaction
logs will be available at "logs/transactions.log"
Logging options are configurable in "conf/logback.xml". The file is a standard logback configuration file.
   For information on how to edit this file see http://logback.qos.ch/manual/configuration.html


