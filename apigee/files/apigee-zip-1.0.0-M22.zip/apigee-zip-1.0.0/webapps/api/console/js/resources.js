var providerName = false;
var providerClass = false;
var providerDescription = {};
var openIndex = [];

$(document).ready(function() {
  providerName = getProviderName();
  writePageElements();
  getDescription(providerName);
});

function getProviderName() {
  var thisProviderName = getQueryParam(document.location.href, "provider") || "Twitter";
  return thisProviderName;
}

function writePageElements() {
  if (providerName) {
    providerClass = providerName.toLowerCase().trim().replace(/\s+/gi,'');
    $("#breadcrumb").append('<li class="provider_icon provider_'+providerClass+'">'+providerName+'</li>');
    $("#provider_header").addClass("provider_icon provider_"+providerClass);
  }
}

function getDescription(theProvider) {
  $.ajax({
    url:'json/'+theProvider.toLowerCase()+'.json',
    dataType:'text',
    success: function(data,textStatus,jqXHR) {
      parseDescription(theProvider,data);
    },
    error: function(jqXHR, textStatus, errorThrown) {
      console.log(jqXHR);
    }
  }); 
}

function parseDescription(theProvider,data) {
  var titleArray = {};
  var itemIterator = 0;
  var data = parseAndReturn(data);
  if (data.hasOwnProperty("application") && (data.application.hasOwnProperty("resources") && data.application.resources.hasOwnProperty("items"))) {
    providerDescription[theProvider] = data.application.resources;
    $("#resource_list").html('');
    var theItems = data.application.resources.items;
    var colorMap = {
      "GET" : "blue",
      "POST" : "green",
      "PUT" : "orange",
      "DELETE" : "red"
    };
    for (var itemKey in theItems) {
      var itemVal = theItems[itemKey];
      if (itemVal.hasOwnProperty("method") && itemVal.method.hasOwnProperty("apigee:tags") && itemVal.method["apigee:tags"].hasOwnProperty("primary")) {
        var thisTitle = itemVal.method["apigee:tags"].primary;
        var sectionId;
        if (!titleArray.hasOwnProperty(thisTitle)) {
          sectionId = "section_"+itemIterator++;
          titleArray[thisTitle] = {"id":sectionId};
          $("#resource_list").append('<section id="'+sectionId+'"><h2 class="resource_title expanded_header">'+thisTitle+'<span></span></h2><table><tr class="reverse"><th>Resource</th><th>Summary</th><th>Docs</th><th>Auth Required?</th></tr></table></section>');
        } else {
          sectionId = titleArray[thisTitle].id;
        }
        var itemPath = itemVal.path.split('.')[0];
        var lozengeClass = colorMap[itemVal.method.name] || "";
        var newRow = '<tr><td><span class="lozenge left '+lozengeClass+'">'+itemVal.method.name+'</span><a href="'+itemPath+'" title="view in console" class="set_request" verb="'+itemVal.method.name+'">'+itemPath+'</a></td><td>'+itemVal.method.doc.content+'</td><td><a href="'+itemVal.method.doc["apigee:url"]+'" class="pop_win" title="open docs in a new window"></a></td><td>';
        newRow += (itemVal.method["apigee:authentication"].required === 'true') ? '<a href="#" class="auth_required" title="'+theProvider+' sign-in required" onclick="return false;"></a>' : '<a href="#" class="no_auth_required" title="no authorization required" onclick="return false;"></a>';
        $("#"+sectionId).find('table').append(newRow + '</td></tr>');
      }
    }
  }
  setUpLinks();
  doTwipsies();
}

function setUpLinks() {
  $("body").find("a.pop_win").click(function() {
    window.open(this.href);
    return false;
  });
  $("body").find("a.set_request").click(function() {
    localStorage.resourceURL = $(this).attr('href') + '.json';
    localStorage.doSnapshot = 'true';
    localStorage.snapVerb = $(this).attr('verb');
    localStorage.removeItem("jsonObj");
    //document.location.href = "v2.html";
    parent.location.href = "https://apigee.com/console/"+providerClass;
    return false;
  });
  $("body").find("h2.resource_title").toggle(function() {
    var parentNode = $(this).parent();
    openIndex[parseInt($(parentNode).attr("id").split("section_")[1])] = 0;
    localStorage.openIndex = openIndex;
    parentNode.find("table").slideUp('fast');
    $(this).removeClass("expanded_header");
    $(this).addClass("collapsed_header");
    return false;
  },
  function() {
    var parentNode = $(this).parent();
    openIndex[parseInt($(parentNode).attr("id").split("section_")[1])] = 1;
    localStorage.openIndex = openIndex;
    parentNode.find("table").slideDown('fast');
    $(this).removeClass("collapsed_header");
    $(this).addClass("expanded_header");
    return false;
  });
  $("#provider_header").find("a.expand_categories").click(function() {
    $("table").each(function(index) {
      if ($(this).css("display") === "none") $(this).parent().find("h2.resource_title").click();
    });
    return false;
  });
  $("#provider_header").find("a.collapse_categories").click(function() {
    $("table").each(function(index) {
      if ($(this).css("display") != "none") $(this).parent().find("h2.resource_title").click();
    });
    return false;
  });
  if (localStorage.openIndex) {
    openIndex = localStorage.openIndex.split(",");
    for (var i=0; i<openIndex.length; i++) {
      var thisIndex = openIndex[i];
      if (thisIndex === "0") $("#section_"+i).find("h2.resource_title").click();
    }
  }
}

//utility functions
function makeUniqueArray(theArray) {
  var cleanArray = new Array();
  for (var i=0; i<theArray.length; i++) {
    var oldItem = theArray[i];
    var matchFound = false;
    for (var j=0; j<cleanArray.length; j++) {
      if (oldItem == cleanArray[j]) {
        matchFound = true;
      }
    }
    if (matchFound == false) {
      cleanArray.push(oldItem);
    }
  }
  return cleanArray;
}

function forEach(array, action) {
  for (var forEachI = 0; forEachI < array.length; forEachI++) {
    action(array[forEachI]);
  }
}

function parseAndReturn(theText) {
  var theJson = '';
  try {
    theJson = $.parseJSON(theText);
  } catch (e) {
    theJson = theText;
  }
  return theJson;
}

function getQueryParam(theUrl, theParam) {
  var paramVal = false;
  var queryArray = theUrl.split("?");
  if (queryArray.length > 1) {
    var allParams = queryArray[1].split("&");
    var getParam = function(thisParam) {
      var paramArray = thisParam.split("=");
      if ((paramArray.length > 1) && (paramArray[0] == theParam)) paramVal = paramArray[1];
    }
    forEach(allParams, getParam);
  }
  return paramVal;
}
