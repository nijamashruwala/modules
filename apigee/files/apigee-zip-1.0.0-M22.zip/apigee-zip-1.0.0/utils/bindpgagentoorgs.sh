#!/bin/sh

# This script will add a bunch of secondary paths to ZooKeeper

if [ ! $APIGEE_HOME ]
then
  echo "Error: APIGEE_HOME must be set"
  exit 2
fi

KER=${APIGEE_HOME}/lib/kernel
IS=${APIGEE_HOME}/lib/infra/services
TP=${APIGEE_HOME}/lib/thirdparty
AM=${APIGEE_HOME}/lib/analytics/migration

CLASSPATH=${AM}/pgagent-migration-support-1.0.0.jar:${KER}/kernel-api-1.0.0.jar:${KER}/microkernel-1.0.0.jar:${IS}/server-binding-1.0.0.jar:${IS}/registration-1.0.0.jar:${TP}/curator-client-0.6.4.jar:${TP}/curator-framework-0.6.4.jar:${TP}/zookeeper-3.3.3.jar:${TP}/guava-r09.jar:${TP}/cxf-api-2.4.7.jar:${TP}/log4j-1.2.14.jar:${TP}/commons-digester-2.1.jar:${TP}/slf4j-api-1.6.1.jar:$(echo ${TP}/*.jar | tr ' ' ':'):$(echo ${IS}/*.jar | tr ' ' ':'):$(echo ${KER}/*.jar | tr ' ' ':')
export CLASSPATH
echo $CLASSPATH
echo "----------"

java com.apigee.analytics.migration.pgagent.PGAgentToOrgBinder $*
