#!/bin/sh

# This script will add a bunch of secondary paths to ZooKeeper

if [ ! $APIGEE_HOME ]
then
  echo "Error: APIGEE_HOME must be set"
  exit 2
fi

KER=${APIGEE_HOME}/lib/kernel
GW=${APIGEE_HOME}/lib/gateway
IL=${APIGEE_HOME}/lib/infra/libraries
IS=${APIGEE_HOME}/lib/infra/services
TP=${APIGEE_HOME}/lib/thirdparty
AM=${APIGEE_HOME}/lib/analytics/migration

CLASSPATH=${AM}/r22-zk-migration-1.0.0.jar:${KER}/kernel-api-1.0.0.jar:${KER}/microkernel-1.0.0.jar:${IS}/server-binding-1.0.0.jar:${IS}/registration-1.0.0.jar:${TP}/curator-client-0.6.4.jar:${TP}/curator-framework-0.6.4.jar:${TP}/zookeeper-3.3.3.jar:${TP}/guava-r09.jar:${TP}/cxf-api-2.4.7.jar:${TP}/log4j-1.2.14.jar:${TP}/commons-digester-2.1.jar:${TP}/slf4j-api-1.6.1.jar:$(echo ${TP}/*.jar | tr ' ' ':'):$(echo ${IS}/*.jar | tr ' ' ':'):$(echo ${KER}/*.jar | tr ' ' ':'):$(echo ${GW}/libraries/*.jar | tr ' ' ':'):$(echo ${GW}/services/*.jar | tr ' ' ':'):$(echo ${GW}/steps/*.jar | tr ' ' ':'):$(echo ${IL}/*.jar | tr ' ' ':')
export CLASSPATH
echo "----------"

java -Xmx1024m  -DdumpStart=1 -DdumpEnd=2 -DdumpSplit=2 -Daxgrpprefix=axgroup com.apigee.analytics.migration.r22.GroupMigrator $*
