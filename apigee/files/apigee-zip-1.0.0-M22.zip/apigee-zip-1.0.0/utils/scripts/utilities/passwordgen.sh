#!/bin/sh
#this file is used to encrypt password/decrypt encrypted password

if [ ! $APIGEE_HOME ]
then
  echo "Error: APIGEE_HOME must be set"
  exit 2
fi

if [ $# -lt 1 ]; then
        echo "Usage: $0  <password>";
        exit 1;
fi

org=$1;
env=$2;


KER=${APIGEE_HOME}/lib/kernel
IS=${APIGEE_HOME}/lib/infra/services
TP=${APIGEE_HOME}/lib/thirdparty
AL=${APIGEE_HOME}/lib/analytics/libraries

CLASSPATH=${AL}/analytics-libraries-util-1.0.0.jar:${KER}/kernel-api-1.0.0.jar:${KER}/microkernel-1.0.0.jar:${IS}/server-binding-1.0.0.jar:${IS}/registration-1.0.0.jar:${TP}/curator-client-0.6.4.jar:${TP}/curator-framework-0.6.4.jar:${TP}/zookeeper-3.3.3.jar:${TP}/guava-r09.jar:${TP}/cxf-api-2.4.7.jar:${TP}/log4j-1.2.14.jar:${TP}/commons-digester-2.1.jar:${TP}/slf4j-api-1.6.1.jar:$(echo ${TP}/*.jar | tr ' ' ':'):$(echo ${IS}/*.jar | tr ' ' ':'):$(echo ${KER}/*.jar | tr ' ' ':')
export CLASSPATH


java  com.apigee.analytics.util.des.DESMaskingUtil $1 $2

