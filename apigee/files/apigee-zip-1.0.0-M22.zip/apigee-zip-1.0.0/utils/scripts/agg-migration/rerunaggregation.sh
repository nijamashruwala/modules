#!/bin/bash


if [ $# -lt 3 ]; then
        echo "Usage: $0 <Organization> <Env> <postgresuser> <database>";
        exit 1;
fi

org=$1;
env=$2;
postgresuser=$3;
database=$4;
fact_table=analytics."\"${org}.${env}".fact\";
agg_apitable=analytics."\"${org}.${env}".agg_api\";

maxFactTimeStamp=`psql -U ${postgresuser} -d ${database} -c "select max(client_received_start_timestamp) from ${fact_table} " |grep -v "max" |grep -v "\(1 row\)" |grep -v '^.-'`
maxFactTimeStamp=${maxFactTimeStamp%% }; 
maxFactTimeStampEpoch=$(date -d"$maxFactTimeStamp" +%s);
maxFactTimeStampEpoch=$maxFactTimeStampEpoch-24*60*60;
minFactTimeStampEpoch=$maxFactTimeStampEpoch-29*24*60*60;

echo "maxFactTimeStampEpoch $maxFactTimeStampEpoch minFactTimeStampEpoch $minFactTimeStampEpoch";
maxFactTimeStamp=`psql -U ${postgresuser} -d ${database} -c "select to_timestamp($maxFactTimeStampEpoch)"|grep -v "to_timestamp" |grep -v "\(1 row\)" |grep -v '^.-'`;
minFactTimeStamp=`psql -U ${postgresuser} -d ${database} -c "select to_timestamp($minFactTimeStampEpoch)"|grep -v "to_timestamp" |grep -v "\(1 row\)" |grep -v '^.-'`;

echo "maxFactTimeStamp $maxFactTimeStamp minFactTimeStamp $minFactTimeStamp";
echo "Deleting records from  and creating new agg_api table"
psql -U ${postgresuser} -d ${database} -c "DELETE FROM $agg_apitable WHERE timestamp <'$maxFactTimeStamp' and timestamp >='$minFactTimeStamp'";


echo "Creating temp table to store timestamp";
psql -U ${postgresuser} -d ${database} -c "create table  if not exists analytics.tmp_aggregation_state(customer text,aggregatetype text ,lastaggregated_time timestamp)";
psql -U ${postgresuser} -d ${database} -c "delete from  analytics.tmp_aggregation_state WHERE customer='${org}~${env}' and aggregatetype ='topapi'";
echo "Inserting analytics.tmp_aggregation_state for topapi ";
psql -U ${postgresuser} -d ${database} -c  "INSERT INTO analytics.tmp_aggregation_state values('${org}~${env}','topapi','$maxFactTimeStamp')";

lastaggregatedtime=$minFactTimeStamp; #remove trailing spaces
echo "lastaggregated time:" $lastaggregatedtime
echo "Creating function performAggregation"
psql -U ${postgresuser} -d ${database} -f performaggregation.sql 

echo " $(date -d"$maxFactTimeStamp" +%s) -gt $(date -d"$lastaggregatedtime" +%s)";
while [ $(date -d"$maxFactTimeStamp" +%s) -gt $(date -d"$lastaggregatedtime" +%s) ] 
	do
	echo "Performing aggregation  for $lastaggregatedtime ";
        psql -U ${postgresuser} -d ${database}  -c "select * from analytics.performAggregation('${org}' ,'${env}' ,'${lastaggregatedtime}')";	
	lastaggregatedtime=`psql -U ${postgresuser} -d ${database} -c "select lastaggregated_time from analytics.tmp_aggregation_state where customer='${org}~${env}' and aggregatetype ='topapi'" |grep -v "lastaggregated_time"|grep -v "\(1 row\)" |grep -v '^.-'`
	lastaggregatedtime=${lastaggregatedtime%% }; #remove trailing spaces
	done
echo "Updating last aggregated timestamp $maxFactTimeStamp";
psql -U ${postgresuser} -d ${database} -c "UPDATE analytics.tmp_aggregation_state SET lastaggregated_time ='$maxFactTimeStamp'  WHERE customer='${org}~${env}' and aggregatetype ='topapi'";
