CREATE OR REPLACE FUNCTION analytics.performAggregation(IN organizationinfo text,IN environmentinfo text,IN minFactTime text)
  RETURNS void AS
$BODY$
DECLARE
        organizationtext                             ALIAS FOR $1;
        environmenttext                              ALIAS FOR $2;
	minFactTimeText                              ALIAS FOR $3;
        facttable                                    text;
        agg_api                                      text;
        minFactTimeStamp                             timestamp;
        maxFactTimeStamp                             timestamp;
        agg_api_query                                text;
        customerNDenv                                text;
        precesion                                    text;
	topapi                                       text;

BEGIN
                facttable = 'analytics.'||'"'||cast( organizationtext as text) ||'.'|| cast(environmenttext as text)|| '.'||'fact' ||'"' ;
                agg_api = 'analytics.'||'"'|| cast(organizationtext as text) ||'.'|| cast(environmenttext as text)|| '.'||'agg_api' ||'"' ;
		customerNDenv=organizationtext||'~'||environmenttext;
                precesion='minute';
		topapi='topapi';
                minFactTimeStamp= CAST (minFactTimeText AS TIMESTAMP);
                maxFactTimeStamp= CAST (minFactTimeStamp AS TIMESTAMP)+INTERVAL '1 days';


                        agg_api_query='insert into '|| agg_api  ||'(apiproxy, api_product, end_point_response_time, total_response_time, max_response_time, min_response_time, data_exchange_size,  error_count, message_count,"timestamp", cache_hit)' || '(SELECT  apiproxy,api_product,cast(   SUM(target_response_time )  as bigint )  AS end_point_response_time,cast(  SUM(total_response_time )  as bigint )  AS total_response_time,cast(  MAX(total_response_time )  as bigint ) AS max_response_time,cast(  MIN(total_response_time )  as bigint )  AS min_response_time, SUM(request_size+response_size )    AS data_exchange_size, SUM( is_error)  AS error_count, COUNT(apiproxy)   AS  message_count, date_trunc('||quote_literal(precesion)||', client_received_start_timestamp) AS  timestamp, SUM(cache_hit)   AS  cache_hit FROM ' ||facttable ||' WHERE client_received_start_timestamp > ' || quote_literal(minFactTimeStamp) || ' AND client_received_start_timestamp <= '|| quote_literal(maxFactTimeStamp)  ||' GROUP BY  apiproxy,timestamp,api_product)';


                EXECUTE agg_api_query;
		EXECUTE 'UPDATE analytics.tmp_aggregation_state SET lastaggregated_time =' ||quote_literal(maxFactTimeStamp)||' WHERE customer='||quote_literal(customerNDenv)||' and aggregatetype ='||quote_literal(topapi);
EXCEPTION
WHEN plpgsql_error THEN
END;
$BODY$
    LANGUAGE plpgsql;
