#!/usr/bin/env python

import base64
import getpass
import httplib
import re
import readline
import sys
import urlparse

def getInput(prompt, default):
  if len(default) > 0:
    return raw_input('%s: ' % prompt)
  return raw_input('%s (%s): ' % (prompt, default))

def confirm(prompt):
  conf = raw_input('%s? ' % prompt)
  if conf.lower() == 'yes' or conf.lower() == 'y':
    return True
  return False

class Onboard:
  def __init__(self):
    self.validName = re.compile('[A-Za-z][A-Za-z0-9\-\_]*$')
    self.validHostName = re.compile('[A-Za-z][A-Za-z0-9\-\_\.]*$')

    self.mgmtHost = 'http://management:8080'
    self.userName = 'admin'
    self.pw = ''
    self.organization = ''
    self.environment = ''
    self.hostAlias = ''
    self.keystore = ''
    self.keyalias = ''
    self.keypass = ''
    self.region = ''
    self.pod = ''
    self.servers = list()

  def openConnection(self):
    if self.httpScheme == 'https':
      conn = httplib.HTTPSConnection(self.httpHost)
    else:
      conn = httplib.HTTPConnection(self.httpHost)
    return conn

  def httpCall(self, verb, uri, headers, body):
    conn = self.openConnection()
    if headers == None:
      hdrs = dict()
    else:
      hdrs = headers
    hdrs['Authorization'] = 'Basic %s' % base64.b64encode(self.login)
    conn.request(verb, uri, body, hdrs)
    return conn.getresponse()

  def uriExists(self, uri):
    resp = self.httpCall('GET', uri, None, None)
    if (resp.status == 200):
      return True
    else:
      return False

  def getUri(self, uri):
    resp = self.httpCall('GET', uri, None, None)
    return resp.read()

  def postXml(self, uri, msg):
    hdrs = {'Content-Type' : 'application/xml'}
    resp = self.httpCall('POST', uri, hdrs, msg)
    return resp

  def postForm(self, uri, msg):
    hdrs = {'Content-Type' : 'application/x-www-form-urlencoded'}
    resp = self.httpCall('POST', uri, hdrs, msg)
    return resp

  def readBasicInput(self):
    self.userName = getInput('Apigee Admin User Name', self.userName)
    self.pw = getpass.getpass('Apigee admin password: ')
    self.mgmtHost = getInput('Management host URL', self.mgmtHost)
    self.organization = getInput('Organization', self.organization)
    self.region = getInput('Region', self.region)
    self.pod = getInput('Pod', self.pod)
    self.keystore = getInput('SSL key store file name (blank for no SSL keys)', self.keystore)
    self.keyalias = getInput('Alias name in key store file', self.keyalias)
    self.keypass = getpass.getpass('Key store password: ')
    if self.validName.match(self.organization) == None:
      print 'Organization name must contain only letters and numbers and start with a letter'
      return False

    print 'Admin user:    %s' % self.userName
    print 'Organization:  %s' % self.organization
    print 'Region:        %s' % self.region
    print 'Pod:           %s' % self.pod
    return confirm('Is this correct (y/n)')

  def readEnvironmentInput(self):
    self.environment = getInput('Environment', self.environment)
    self.hostAlias = getInput('Host Alias', self.hostAlias)
    self.servers = list()
    newServer = raw_input('Message Processor UUID: (return to exit) ')
    while len(newServer) > 0:
      self.servers.append(newServer)
      newServer = raw_input('Message Processor UUID: (return to exit) ')
    if self.validName.match(self.environment) == None:
      print 'Environment name must contain only letters and numbers and start with a letter'
      return False
    if self.validHostName.match(self.hostAlias) == None:
      print 'Host alias must contain only letters, numbers, dashes, and underscores'
      return False
    print 'Environment:            %s' % self.environment
    print 'Host alias:             %s' % self.hostAlias
    for s in self.servers:
      print 'Message Processor UUID: %s' % s
      return confirm('Is this correct (y/n)') 

  def makeKeys(self):
    if len(self.keystore) == 0 or len(self.keyalias) == 0:
      print 'No SSL keys defined'
      return False
    ksFile = open(self.keystore, 'r')
    resp = self.httpCall('POST', '/v1/o/%s/e/%s/keystores?action=import&name=%s&password=%s' % \
                         (self.organization, self.environment, self.keystore, self.keypass),
                         { 'Content-Type' : 'application/octet-stream' },
                         ksFile.read())
    print resp.read()
    if resp.status != 200 and resp.status != 201:
      print 'Error creating keystore: %i' % resp.status
      return False 
    return True

  def makeEnvironment(self):
    while self.readEnvironmentInput() == False:
      pass

    if self.uriExists('/v1/organizations/%s/environments/%s' % (self.organization, self.environment)):
      print 'The %s environment already exists.' % self.environment
      return
    
    print 'Creating environment %s' % self.environment
    response = self.postXml('/v1/organizations/%s/environments' % self.organization,
                           '<Environment name="%s"/>' % self.environment)
    print response.read()
    if response.status != 200 and response.status != 201:
      print 'Error creating environment.'
      return

    for s in self.servers:
      print 'Adding message processor %s' % s
      response = self.postForm('/v1/organizations/%s/environments/%s/servers' % (self.organization, self.environment), 'action=add&uuid=%s' % s)
      print response.read()
      if response.status != 200 and response.status != 201 and response.status != 204:
        print 'Error %i adding server.' % response.status
        return

    print self.getUri('/v1/organizations/%s/environments/%s/servers' % (self.organization, self.environment))

    if self.uriExists('/v1/organizations/%s/environments/%s/virtualhosts/default' % (self.organization, self.environment)):
      print 'Default virtual host already exists'
      return

    print 'Adding "default" virtual host on port 80'
    virtualHostDef = \
      '<VirtualHost name="default"> \
       <HostAliases><HostAlias>%s</HostAlias></HostAliases> \
       <Port>80</Port> \
       </VirtualHost>' % self.hostAlias

    response = self.postXml('/v1/organizations/%s/environments/%s/virtualhosts' % (self.organization, self.environment), virtualHostDef)
    print response.read()
    if response.status != 200 and response.status != 201:
      print 'Error adding virtual host.'
      return

    if self.makeKeys():
      print 'Adding "secure" virtual host on port 443'
      virtualHostDef = \
        '<VirtualHost name="secure"> \
         <HostAliases><HostAlias>%s</HostAlias></HostAliases> \
         <Port>443</Port> \
         <SSLInfo><Enabled>true</Enabled><KeyStore>%s</KeyStore><KeyAlias>%s</KeyAlias></SSLInfo> \
         </VirtualHost>' % (self.hostAlias, self.keystore, self.keyalias)

      response = self.postXml('/v1/organizations/%s/environments/%s/virtualhosts' % (self.organization, self.environment), virtualHostDef)
      print response.read()
      if response.status != 200 and response.status != 201:
        print 'Error adding virtual host.'
        return

  def run(self):
    while self.readBasicInput() == False:
      pass

    self.login = '%s:%s' % (self.userName, self.pw)
    parsed = urlparse.urlparse(self.mgmtHost)
    self.httpScheme = parsed[0]
    self.httpHost = parsed[1]

    if self.uriExists('/v1/organizations/%s' % self.organization):
      print 'The %s organization already exists.' % self.organization
    else:
      print 'Creating organization %s' % self.organization
      response = self.postXml('/v1/organizations', 
                       '<Organization name="%s"/>' % self.organization)
      print response.read()
      if response.status != 200 and response.status != 201:
        print 'Error %i creating organization. Exiting' % response.status
        sys.exit(4)
      print 'Adding to pod %s' % self.pod
      response = self.postForm('/v1/organizations/%s/pods' % self.organization,
                              'region=%s&pod=%s' % (self.region, self.pod))
      print response.read()
      if response.status != 200 and response.status != 201:
        print 'Error %i associating with pod. Exiting' % response.status
        sys.exit(4)

      self.makeEnvironment()
      while confirm('Do you want to create another environment'):
        self.makeEnvironment()

      print 'Onboarding is complete. There are a few steps remaining:'
      print '1) This script does not automatically create a DNS alias. Please create one.'
      print '2) This script does not automatically set up analytics.'
      print '3) This script does not create users or add them to the organization.'

runner = Onboard()
runner.run()

