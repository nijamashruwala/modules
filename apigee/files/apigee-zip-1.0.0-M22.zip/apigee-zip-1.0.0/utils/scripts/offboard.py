#!/usr/bin/env python

import base64
import getpass
import httplib
import readline
import StringIO
import sys
import urlparse
import xml.dom.minidom

def getInput(prompt, default):
  if len(default) > 0:
    return raw_input('%s: ' % prompt)
  return raw_input('%s (%s): ' % (prompt, default))

def confirm(prompt):
  conf = raw_input('%s? ' % prompt)
  if conf.lower() == 'yes' or conf.lower() == 'y':
    return True
  return False

def getElementText(n):
    c = n.firstChild
    str = StringIO.StringIO()
    while c != None:
        if c.nodeType == xml.dom.Node.TEXT_NODE:
            str.write(c.data)
        c = c.nextSibling
    return str.getvalue().strip()

def getElementVal(n, name):
    c = n.firstChild
    while c != None:
      if c.nodeName == name:
        return getElementText(c)
      c = c.nextSibling
    return None

class Offboard:
  def __init__(self):
    self.mgmtHost = 'http://management:8080'
    self.userName = 'admin'
    self.pw = ''
    self.organization = ''

  def httpCall(self, verb, uri, headers, body):
    if self.httpScheme == 'https':
      conn = httplib.HTTPSConnection(self.httpHost)
    else:
      conn = httplib.HTTPConnection(self.httpHost)
    if headers == None:
      hdrs = dict()
    else:
      hdrs = headers
    hdrs['Authorization'] = 'Basic %s' % base64.b64encode(self.login)
    conn.request(verb, uri, body, hdrs)
    return conn.getresponse()

  def uriExists(self, uri):
    resp = self.httpCall('GET', uri, None, None)
    if (resp.status == 200):
      return True
    else:
      return False

  def deleteUri(self, uri):
    resp = self.httpCall('DELETE', uri, None, None)
    return resp

  def readXml(self, uri):
    resp = self.httpCall('GET', uri, { 'Accept' : 'application/xml' }, None)
    return xml.dom.minidom.parse(resp)

  def postForm(self, uri, msg):
    hdrs = {'Content-Type' : 'application/x-www-form-urlencoded'}
    resp = self.httpCall('POST', uri, hdrs, msg)
    return resp

  def postBinary(self, uri, msg):
    hdrs = {'Content-Type' : 'application/octet-stream'}
    resp = self.httpCall('POST', uri, hdrs, msg)
    return resp

  def readBasicInput(self):
    self.userName = getInput('Apigee Admin User Name', self.userName)
    self.pw = getpass.getpass('Apigee admin password: ')
    self.mgmtHost = getInput('Management host URL', self.mgmtHost)
    self.organization = getInput('Organization', self.organization)

    print 'Admin user:    %s' % self.userName
    print 'Organization:  %s' % self.organization
    return confirm('Is this correct (y/n)')

  def offboardEnvironment(self, envName):
    # Get list of deployments
    doc = self.readXml('/v1/o/%s/e/%s/deployments' % (self.organization, envName))
    proxies = doc.getElementsByTagName('APIProxy')
    for proxy in proxies:
      name = proxy.getAttribute('name')
      revisions = proxy.getElementsByTagName('Revision')
      for rev in revisions:
        revision = rev.getAttribute('name')
        print 'Undeploying API %s revision %s' % (name, revision)
        resp = self.postBinary('/v1/o/%s/apis/%s/deployments?action=undeploy&env=%s&revision=%s' % \
                             (self.organization, name, envName, revision), '')
        print resp.read()
        print 'Undeploy status %i' % resp.status

    # Get list of APIs
    doc3 = self.readXml('/v1/o/%s/apis' % self.organization)
    apis = doc3.getElementsByTagName('Item')
    for api in apis:
      apiName = getElementText(api)
      print 'Deleting API proxy %s' % apiName
      resp = self.deleteUri('/v1/o/%s/apis/%s' % (self.organization, apiName))

    # Get list of message processor servers
    doc2 = self.readXml('/v1/o/%s/e/%s/servers' % (self.organization, envName))
    svrs = doc2.getElementsByTagName('Item')
    for svr in svrs:
      # Remove each server from the environment
      svrName = getElementText(svr)
      print 'Removing server %s from environment %s' % (svrName, envName)
      self.postForm('/v1/o/%s/e/%s/servers' % (self.organization, envName),
                    'action=remove&uuid=%s' % svrName)

    print 'Deleting environment %s' % envName
    resp = self.deleteUri('/v1/o/%s/e/%s' % (self.organization, envName))
    print resp.read()

  def run(self):
    while self.readBasicInput() == False:
      pass
    if confirm ('The organization %s will be completely deleted, with all proxies and keys. Is that what you want to do (y/n)' % self.organization) == False:
      return

    self.login = '%s:%s' % (self.userName, self.pw)
    parsed = urlparse.urlparse(self.mgmtHost)
    self.httpScheme = parsed[0]
    self.httpHost = parsed[1]

    if self.uriExists('/v1/o/%s' % self.organization) == False:
      print 'The organization does not exist.'
      return

    # Get list of environments
    doc = self.readXml('/v1/o/%s/e' % self.organization)
    if doc == None:
      print 'Error getting environment list'
      return
    envs = doc.getElementsByTagName('Item')
    for env in envs:
      envName = getElementText(env)
      self.offboardEnvironment(envName)

    # Get the list of pods
    doc = self.readXml('/v1/o/%s/pods' % self.organization)
    if doc == None:
      print 'Error getting pod list'
      return
    pods = doc.getElementsByTagName('Pod')
    for p in pods:
      pName = getElementVal(p, 'Name')
      rName = getElementVal(p, 'Region')
      print 'Removing organization from pod %s' % pName
      resp = self.postForm('/v1/o/%s/pods' % self.organization, 
                           'action=remove&region=%s&pod=%s' % (rName, pName))

    print 'Deleting the top-level organization'
    resp = self.deleteUri('/v1/o/%s' % self.organization)
    print resp.read()
    if resp.status == 200 or resp.status == 201:
      print 'Done.'

runner = Offboard()
runner.run()

