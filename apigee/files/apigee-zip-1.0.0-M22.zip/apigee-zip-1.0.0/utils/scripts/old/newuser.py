import base64
import httplib
import sys

mgmtHost = 'api.enterprise.apigee.com'

def httpCall(verb, uri, headers, body):
  conn = httplib.HTTPSConnection(mgmtHost)
  if headers == None:
    hdrs = dict()
  else:
    hdrs = headers
  hdrs['Authorization'] = 'Basic %s' % base64.b64encode(login)
  conn.request(verb, uri, body, hdrs)
  return conn.getresponse()

userName = raw_input('Admin user name: ')
pw = raw_input('Admin Password: ')
organization = raw_input('Organization: ')
newUser = raw_input('New user name: ')
newPw = raw_input('New User password: ')
newFirst = raw_input('First name: ')
newLast = raw_input('Last name: ')
newMail = raw_input('E-Mail: ')

login = '%s:%s' % (userName, pw)

print 'Organization:    %s' % organization
print 'User:            %s' % newUser
print 'First name:      %s' % newFirst
print 'Last name:       %s' % newLast
print 'Email:           %s' % newMail

ok = raw_input('Is this correct (y/n)? ')

if ok.lower() != 'y':
  print 'Exiting.'
  sys.exit(3)

userDoc = \
  '<User id="%s">' \
    '<EmailId>%s</EmailId>' \
    '<FirstName>%s</FirstName>' \
    '<LastName>%s</LastName>' \
    '<Password>%s</Password>' \
  '</User>' % \
    (newUser, newMail, newFirst, newLast, newPw)

resp = httpCall('POST', 
                '/v1/organizations/%s/users' % organization,
                {'Content-Type' : 'application/xml'}, userDoc)

if resp.status != 200 and resp.status != 201 and resp.status != 204:
  print 'Error %i creating user:\n%s' % (resp.status, resp.read())
  sys.exit(4)

print 'User %s successfully created for organization %s' % \
  (newUser, organization)

