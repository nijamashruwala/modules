import email.mime.text
import smtplib
import sys

import userinfo

From = raw_input('Your email: ')
To = raw_input('User email: ')
pw = raw_input('Your GMail password: ')

ok = raw_input('You are about to send an email from %s to %s. Are you sure (y/n)? ' % \
  (From, To))
if ok.lower() != 'y':
  print 'Exiting.'
  sys.exit(1)

MailerHost = 'smtp.gmail.com'
MailerPort = 465

getter = userinfo.InfoGetter()
getter.getAllInput()
envs = getter.getEnvironments()
text = getter.makeNiceHTML(envs)

print 'Here is the message that you will send:\n', text

message = email.mime.text.MIMEText(text, 'html')
message['From'] = From
message['To'] = To
message['Subject'] = 'Welcome to Apigee Enterprise'

mailer = smtplib.SMTP_SSL(MailerHost, MailerPort)
mailer.login(From, pw)
mailer.sendmail(From, To, message.as_string())
mailer.quit()

print 'Done.'
