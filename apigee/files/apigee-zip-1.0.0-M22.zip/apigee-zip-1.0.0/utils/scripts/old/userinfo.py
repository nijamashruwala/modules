import base64
import httplib
import json
import StringIO

def defaultInput(prompt, default):
  if default == None:
    result = raw_input('%s: ' % prompt)
  else:
    result = raw_input('%s: (%s)' % (prompt, default))
  if result == None or len(result) == 0:
    result = default
  return result

class InfoGetter:
  def httpCall(self, verb, uri, headers, body):
    login = '%s:%s' % (self.AdminUser, self.AdminPW)
    conn = httplib.HTTPSConnection(self.mgmtHost)
    if headers == None:
      hdrs = dict()
    else:
      hdrs = headers
    hdrs['Authorization'] = 'Basic %s' % base64.b64encode(login)
    conn.request(verb, uri, body, hdrs)
    return conn.getresponse()

  def getJson(self, uri):
    headers = { 'Accept' : 'application/json' }
    resp = self.httpCall('GET', uri, headers, None)
    return json.load(resp)

  def getList(self, uri):
    resp = self.getJson(uri)
    l = resp['List']['Item']
    if not isinstance(l, list):
      return [l]
    return l

  def __init__(self):
    self.mgmtHost = 'api.enterprise.apigee.com'
    self.AdminUser = None
    self.AdminPW = None
    self.Organization = None
    self.UserName = None

  def getInput(self):
    self.AdminUser = defaultInput('Admin User Name', self.AdminUser)
    self.AdminPW = defaultInput('Admin Password', self.AdminPW)
    self.Organization = defaultInput('Organization', self.Organization)
    self.UserName = defaultInput('User Name', self.UserName)
    print 'Admin User:        ', self.AdminUser
    print 'Organization:      ', self.Organization
    print 'User Name:         ', self.UserName

  def getAllInput(self):
    ok = 'n'
    while ok.lower() != 'y':
      self.getInput()
      ok = raw_input('Is this correct (y/n)? ')

  def getUserName(self):
    user = self.getJson('/v1/organizations/%s/users/%s' % (self.Organization, self.UserName))
    return user

  def getEnvironments(self):
    allEnvironments = dict()

    envs = self.getList('/v1/organizations/%s/environments' % self.Organization)
    for env in envs: 
      allHosts = list()
      vhs = self.getList('/v1/organizations/%s/environments/%s/virtualhosts' % \
                         (self.Organization, env))
      for vh in vhs:
        vHost = self.getJson('/v1/organizations/%s/environments/%s/virtualhosts/%s' % \
                              (self.Organization, env, vh))
        alias = vHost['VirtualHost']['HostAliases']['HostAlias']
        port = int(vHost['VirtualHost']['Port'])
        name = vHost['VirtualHost']['@name']
        if port == 80:
          uri = 'http://%s' % alias
        elif port == 443:
          uri = 'https://%s' % alias
        else:
          uri = 'https://%s:%i' % (alias, port)
        allHosts.append({'alias' : alias, 'port' : port, 'name' : name, 'uri' : uri})
      allEnvironments[env] = {'virtualHosts' : allHosts}
    return allEnvironments

  def makeNiceHTML(self, env):
    buf = StringIO.StringIO()
    buf.write('<html><head><title>Welcome to Apigee Enterprise</title></head><body>')
    buf.write('<h1>Welcome to Apigee Enterprise</h1>')
    buf.write('<p>Your username is "%s". Your password has been communicated previously.</p>' % self.UserName)
    buf.write('<p>You may log in using the following URL: <a href="https://enterprise.apigee.com">https://enterprise.apigee.com</a></p>')
    buf.write('<p>You may use the same username and password for the API, for instance:</p>') 
    buf.write('<p>curl -u %s:PASSWORD https://api.enterprise.apigee.com/v1/organizations/%s' % \
        (self.UserName, self.Organization))
    buf.write('<p>(Of course you will replace PASSSWORD with your actual passsword)</p>')
    buf.write('<p>In addition, %i "Environments" have been created for you.</p>' % len(env))
    for e in env.items():
      buf.write('<p><b>Environment Name:</b> %s:</p>' % e[0])
      buf.write('<p>%i virtual hosts:</p>' % len(e[1]['virtualHosts']))
      for v in e[1]['virtualHosts']:
        buf.write('<p><b>Virtual Host Name</b>: %s</p><p>Base URI for API calls: %s</p>' % (v['name'], v['uri']))
    buf.write('<p>Thank you and good luck! Feel free to contact us with any questions</p>')
    buf.write('</body></html>')
    return buf.getvalue()









