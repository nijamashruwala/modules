#!/bin/bash
for i in `psql -U postgres -d apigee -c "select relname from pg_stat_user_tables where relname like '%fact'" | grep fact`;
 do o=`echo $i | cut -d. -f1`;e=`echo $i | cut -d. -f2`;
sh migratingTablesFromR21toR22.sh $o $e 2>&1 |grep -v "already" |grep -v "NOTICE";
echo "Customer ${o} with env ${e} has been Upgraded"
done
echo "Creatingn api pattern table"
psql -U postgres -d apigee -c "create table  analytics.api_pattern(customer text,apiproxy text,groupid int,groupname text,uuid text,verb text,apipattern text)" 2>&1 |grep -v "already";
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_api_pattern_uri_customer\" ON  analytics.api_pattern (customer)" 2>&1 |grep -v "already";
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_api_pattern_uri_groupid\" ON  analytics.api_pattern (groupid)" 2>&1 |grep -v "already";
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_api_pattern_uri_verb\" ON  analytics.api_pattern (verb)" 2>&1 |grep -v "already";
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_api_pattern_apipattern\" ON  analytics.api_pattern (apipattern)" 2>&1 |grep -v "already";
echo "done"
