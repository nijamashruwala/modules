#!/bin/bash

# main

if [ $# -lt 2 ]; then
        echo "Usage: $0 <Organization> <Env>";
        exit 1;
fi

org=$1;
env=$2;
fact_table=analytics."\"${org}.${env}".fact\";
sample_ten=analytics."\"${org}.${env}".smp_ten\";
sample_one=analytics."\"${org}.${env}".smp_one\";
sample_po=analytics."\"${org}.${env}".smp_po\";
agg_uri_pattern=analytics."\"${org}.${env}".agg_uri_pattern\";


psql -U postgres -d apigee -c "ALTER TABLE $fact_table ADD column x_forwarded_for_ip text";
psql -U postgres -d apigee -c "ALTER TABLE $fact_table ADD column useragent text";
psql -U postgres -d apigee -c "ALTER TABLE $fact_table ADD column target_response_code int";
psql -U postgres -d apigee -c "ALTER TABLE $fact_table ADD column groupid int";

smp_ten=`psql -U postgres -d apigee -c "select relname from pg_stat_user_tables where relname ='${org}.${env}.smp_ten'" |grep ${org}.${env}.smp_ten`;
if [ $smp_ten ]; then
         psql -U postgres -d apigee -c "ALTER TABLE $sample_ten ADD column x_forwarded_for_ip text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_ten ADD column useragent text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_ten ADD column target_response_code int";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_ten ADD column groupid int";
fi

smp_one=`psql -U postgres -d apigee -c "select relname from pg_stat_user_tables where relname ='${org}.${env}.smp_one'" |grep ${org}.${env}.smp_one`;
if [ $smp_one ]; then
         psql -U postgres -d apigee -c "ALTER TABLE $sample_one ADD column x_forwarded_for_ip text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_one ADD column useragent text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_one ADD column target_response_code int";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_one ADD column groupid int";
fi

smp_po=`psql -U postgres -d apigee -c "select relname from pg_stat_user_tables where relname ='${org}.${env}.smp_po'" |grep ${org}.${env}.smp_po`;
if [ $smp_po ]; then
         psql -U postgres -d apigee -c "ALTER TABLE $sample_po ADD column x_forwarded_for_ip text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_po ADD column useragent text";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_po ADD column target_response_code int";
         psql -U postgres -d apigee -c "ALTER TABLE $sample_po ADD column groupid int";
fi


psql -U postgres -d apigee -c "create table  $agg_uri_pattern (apiproxy text ,request_verb text ,groupid int,message_count bigint,error_count bigint,response_time bigint,min_response_time bigint ,max_response_time bigint,request_size bigint ,response_size bigint, timestamp timestamp )";

psql -U postgres -d apigee -c "CREATE INDEX \"analytics_${org}_${env}_agg_uri_pattern_timestamp\" ON analytics.\"${org}.${env}.agg_uri_pattern\"(timestamp)"
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_${org}_${env}_agg_uri_pattern_groupid\" ON analytics.\"${org}.${env}.agg_uri_pattern\"(groupid)"
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_${org}_${env}_agg_uri_pattern_apiproxy\" ON analytics.\"${org}.${env}.agg_uri_pattern\"(apiproxy)"
psql -U postgres -d apigee -c "CREATE INDEX \"analytics_${org}_${env}_agg_uri_pattern_request_verb\" ON analytics.\"${org}.${env}.agg_uri_pattern\"(request_verb)"
