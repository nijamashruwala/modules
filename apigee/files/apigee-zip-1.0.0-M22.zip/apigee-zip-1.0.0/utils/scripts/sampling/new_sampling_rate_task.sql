-- For creating a new sampling rate. The purpose is to pick data from the beginning.
-- Sampling task based on reservoir sampling
-- Ref:- http://en.wikipedia.org/wiki/Reservoir_sampling
-- @in org - customer name
-- @in env - environment of the customer
-- @rates - list of sampling rates for this org~env to sample for
-- @ratesAsWords - list of names/descriptions for the rates to build the name of the sample table - eg - smp_one,smp_ten etc
--               - where one and ten are names for rates 1,10 respectively.

CREATE OR REPLACE FUNCTION analytics.new_sampling_rate_task(IN org text,IN env text,IN rate REAL,IN rateAsWord TEXT,IN startTimeToPick TEXT)
  RETURNS VOID AS
$BODY$
DECLARE
	CHILDTABLE_RECORD analytics.childfactables%ROWTYPE;
	CHILDTABLE TEXT;
	CUSTOMER_IDENTIFIER TEXT;
	CUSTOMER_TABLE_PREFIX TEXT;
	SAMPLING_RATE INT;
	TEMP_STR TEXT;
	LAST_SAMPLED_TIME TIMESTAMP WITHOUT TIME ZONE; -- THE current value read into
	RESERVOIR_SAMPLER_RET TIMESTAMP WITHOUT TIME ZONE := null; -- SAMPLING algo return value
	UPDATED_LAST_SAMPLE_TIME TIMESTAMP WITHOUT TIME ZONE; -- the final value to store into
	MAX_TIME_TO_SAMPLE_OVERRIDE TIMESTAMP WITHOUT TIME ZONE := null;
	MIN_TIME TIMESTAMP WITHOUT TIME ZONE := null;
    USER_PROVIDED_MIN_TIME TIMESTAMP WITHOUT TIME ZONE := null;

     BEGIN

      RAISE NOTICE 'start of sampling task for customer % with env % for rate %',org,env,rate;
      CUSTOMER_IDENTIFIER := org || '~' || env;


      CUSTOMER_TABLE_PREFIX := org || '.' || env || '.';



      execute 'select MIN(client_received_start_timestamp)   from analytics."'|| CUSTOMER_TABLE_PREFIX || 'fact'  || '"' into MIN_TIME;

      if startTimeToPick is not null and length(startTimeToPick) > 0 then
         begin
            --  raise notice 'parsing startTimeToPick % length %',startTimeToPick,length(startTimeToPick);
              USER_PROVIDED_MIN_TIME := cast(startTimeToPick as timestamp without time zone);
              if USER_PROVIDED_MIN_TIME < MIN_TIME then
                  raise notice 'user provided start time < min start time in fact. defaulting to min time in fact';
              else
                  MIN_TIME := USER_PROVIDED_MIN_TIME;
              end if;


           EXCEPTION WHEN OTHERS THEN
                raise notice 'Error while reading start time as timestamp %',startTimeToPick;
                raise notice 'Not running sampling task for new rate';
                MIN_TIME := null;
         end;
      end if;
      if MIN_TIME is NULL then
         return;
      end if;

      raise notice 'START TIME to sample new rate %',MIN_TIME;

            FOR CHILDTABLE_RECORD IN
                select * from analytics.childfactables where customer= CUSTOMER_IDENTIFIER
                and starttime >=
                    (select starttime from analytics.childfactables where customer=CUSTOMER_IDENTIFIER
                        and to_timestamp(starttime/1000) =  date_trunc('day', MIN_TIME)
                        order by starttime asc limit 1
                    )
                and tablename like CUSTOMER_TABLE_PREFIX || 'fact_%'
                order by starttime asc

            LOOP

                BEGIN

                  select to_timestamp(CHILDTABLE_RECORD.starttime/1000) into  LAST_SAMPLED_TIME;
	              select  analytics.reservoir_sampler(org,env,rate,rateAsWord,CHILDTABLE_RECORD.tablename,CHILDTABLE_RECORD.starttime,CHILDTABLE_RECORD.endtime,LAST_SAMPLED_TIME,MAX_TIME_TO_SAMPLE_OVERRIDE,1) into RESERVOIR_SAMPLER_RET;
                  if RESERVOIR_SAMPLER_RET is not null then
                    UPDATED_LAST_SAMPLE_TIME := RESERVOIR_SAMPLER_RET;
                  end if;

                END;

		    END LOOP; -- loop of child tables

		    MAX_TIME_TO_SAMPLE_OVERRIDE = UPDATED_LAST_SAMPLE_TIME;





    --update lst for rates.
    if UPDATED_LAST_SAMPLE_TIME is not null then
         execute 'insert into analytics.sampling_state (customer,lastsampled_time,smp_rate) values('|| quote_literal(CUSTOMER_IDENTIFIER)  || ','
                 || quote_literal(UPDATED_LAST_SAMPLE_TIME) || ',' ||  cast(rate as real) || ')';
         raise notice 'set last sampled time for new rate % for customer % ',rate,quote_literal(CUSTOMER_IDENTIFIER);
     end if;



EXCEPTION WHEN OTHERS THEN
     RAISE NOTICE 'SQL STATE FOUND TO BE % WITH error message % when sampling for org % with env %',SQLSTATE,SQLERRM,org,env;
END;
$BODY$
  LANGUAGE plpgsql






