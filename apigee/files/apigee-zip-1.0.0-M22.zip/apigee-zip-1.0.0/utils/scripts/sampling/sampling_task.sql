-- Sampling task based on reservoir sampling
-- Ref:- http://en.wikipedia.org/wiki/Reservoir_sampling
-- @in org - customer name
-- @in env - environment of the customer
-- @rates - list of sampling rates for this org~env to sample for
-- @ratesAsWords - list of names/descriptions for the rates to build the name of the sample table - eg - smp_one,smp_ten etc
--               - where one and ten are names for rates 1,10 respectively.

CREATE OR REPLACE FUNCTION analytics.sampling_task(IN algo text,IN org text,IN env text,IN rates REAL[],IN ratesAsWords TEXT[] )
  RETURNS VOID AS
$BODY$
DECLARE
	CHILDTABLE_RECORD analytics.childfactables%ROWTYPE;
	CHILDTABLE TEXT;
	CUSTOMER_IDENTIFIER TEXT;
	CUSTOMER_TABLE_PREFIX TEXT;
	SAMPLING_RATE INT;
	TEMP_STR TEXT;
	LAST_SAMPLED_TIME TIMESTAMP WITHOUT TIME ZONE; -- THE current value read into
	TODAYS_TIME TIMESTAMP WITHOUT TIME ZONE; -- THE current value read into
	RESERVOIR_SAMPLER_RET TIMESTAMP WITHOUT TIME ZONE := null; -- SAMPLING algo return value
	UPDATED_LAST_SAMPLE_TIME TIMESTAMP WITHOUT TIME ZONE; -- the final value to store into
	MAX_TIME_TO_SAMPLE_OVERRIDE TIMESTAMP WITHOUT TIME ZONE := null;
	INCLUDE_START_TIME INT := 0;  -- 1 to include 0 to exclude

     BEGIN

      RAISE NOTICE 'start of sampling task for customer % with env %',org,env;
      CUSTOMER_IDENTIFIER := org || '~' || env;
      CUSTOMER_TABLE_PREFIX := org || '.' || env || '.';

      FOR i IN array_lower(rates,1) .. array_upper(rates,1)
        LOOP
        -- First read it wrt the current rate.
        select lastsampled_time from analytics.sampling_state where customer = CUSTOMER_IDENTIFIER and smp_rate=rates[i] into LAST_SAMPLED_TIME ;
        -- if absent read it w/o any constraint (the first time it runs in R22 mode for instance)
        if LAST_SAMPLED_TIME is NULL THEN
		 select lastsampled_time from analytics.sampling_state where customer = CUSTOMER_IDENTIFIER into LAST_SAMPLED_TIME ;
        end if;

        -- If absent this rate has probably never been sampled at all due to the modulo factor till R22.
        if LAST_SAMPLED_TIME is NULL THEN
             execute 'select min(client_received_start_timestamp) from analytics.' || '"' || CUSTOMER_TABLE_PREFIX || 'fact' || '"'  into LAST_SAMPLED_TIME;
             execute 'select date_trunc('|| quote_literal('day') || ',current_timestamp) ' into  TODAYS_TIME;
             raise notice 'LAST_SAMPLED_TIME for org % with env % found to be % while selecting the min fact time ',org,env,LAST_SAMPLED_TIME;
             raise notice 'The current time stamp for org % with env % found to be %',org,env,TODAYS_TIME;
             if LAST_SAMPLED_TIME < TODAYS_TIME then
                raise notice 'resetting LAST_SAMPLED_TIME to todays time for org % with env % Now LST used is %. Originally found to be %',org,env,TODAYS_TIME,LAST_SAMPLED_TIME;
                LAST_SAMPLED_TIME := TODAYS_TIME;
             end if;

             INCLUDE_START_TIME := 1;
        end if;

	    if LAST_SAMPLED_TIME is NOT NULL THEN


            FOR CHILDTABLE_RECORD IN
                select * from analytics.childfactables where customer= CUSTOMER_IDENTIFIER
                and starttime >=
                    (select starttime from analytics.childfactables where customer=CUSTOMER_IDENTIFIER
                        and to_timestamp(starttime/1000) >=  date_trunc('day',  LAST_SAMPLED_TIME)
                        order by starttime asc limit 1
                    )
                and tablename like CUSTOMER_TABLE_PREFIX || 'fact_%'
                order by starttime asc

            LOOP

                BEGIN
                   execute 'select  analytics.' || algo || '(' || quote_literal(org) || ',' || quote_literal(env) || ',' || rates[i] || ','
                  				|| quote_literal(ratesAsWords[i]) || ',' || quote_literal(CHILDTABLE_RECORD.tablename) || ','
                  				|| CHILDTABLE_RECORD.starttime
                  				|| ',' || CHILDTABLE_RECORD.endtime || ',' || quote_nullable(LAST_SAMPLED_TIME) || ','
                  				|| quote_nullable(MAX_TIME_TO_SAMPLE_OVERRIDE)
                  			        || ',' || INCLUDE_START_TIME || ')'
                  	           into RESERVOIR_SAMPLER_RET;


                  if RESERVOIR_SAMPLER_RET is not null then
                    UPDATED_LAST_SAMPLE_TIME := RESERVOIR_SAMPLER_RET;
                  end if;

                END;

		    END LOOP; -- loop of child tables

		    MAX_TIME_TO_SAMPLE_OVERRIDE := UPDATED_LAST_SAMPLE_TIME;


        END IF; -- if last sampled is not null

   END LOOP;

    --update lst for rates.
    if UPDATED_LAST_SAMPLE_TIME is not null then
	    FOR i IN array_lower(rates,1) .. array_upper(rates,1)
	    LOOP
          execute 'select customer from analytics.sampling_state where smp_rate=' || cast(rates[i] as real) || '::real and customer = ' || quote_literal(CUSTOMER_IDENTIFIER) into TEMP_STR;
          if TEMP_STR is not null then
              execute 'update analytics.sampling_state set lastsampled_time = ' || quote_literal(UPDATED_LAST_SAMPLE_TIME)
                || ' where customer = ' || quote_literal(CUSTOMER_IDENTIFIER) || 'and smp_rate=' || cast(rates[i] as real) || '::real' ;

          else
              execute 'insert into analytics.sampling_state (customer,lastsampled_time,smp_rate) values('|| quote_literal(CUSTOMER_IDENTIFIER)  || ','
                 || quote_literal(UPDATED_LAST_SAMPLE_TIME) || ',' ||  cast(rates[i] as real) || ')';
          end if;
	    END LOOP;

	    -- for rollback
	    execute 'select customer from analytics.sampling_state where customer=' || quote_literal(CUSTOMER_IDENTIFIER) || ' and smp_rate is NULL' into TEMP_STR;
	    if TEMP_STR is not null then
	         execute 'update analytics.sampling_state set lastsampled_time = ' || quote_literal(UPDATED_LAST_SAMPLE_TIME) || ' where customer = ' || quote_literal(CUSTOMER_IDENTIFIER) || ' and smp_rate is NULL' ;
        else
          	 execute 'insert into analytics.sampling_state (customer,lastsampled_time) values('|| quote_literal(CUSTOMER_IDENTIFIER)  || ','
				|| quote_literal(UPDATED_LAST_SAMPLE_TIME)  || ')';
	    end if;

     end if;




EXCEPTION WHEN OTHERS THEN
     RAISE NOTICE 'SQL STATE FOUND TO BE % WITH error message % when sampling for org % with env %',SQLSTATE,SQLERRM,org,env;
END;
$BODY$
  LANGUAGE plpgsql






