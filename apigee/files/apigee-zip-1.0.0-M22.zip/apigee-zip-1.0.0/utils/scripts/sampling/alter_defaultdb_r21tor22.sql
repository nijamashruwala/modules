create table  analytics.api_pattern(customer text,apiproxy text,groupid int,groupname text,uuid text,verb text,apipattern text);

CREATE INDEX "analytics_api_pattern_uri_customer" ON  analytics.api_pattern (customer);

CREATE INDEX "analytics_api_pattern_uri_groupid" ON  analytics.api_pattern (groupid);

CREATE INDEX "analytics_api_pattern_uri_verb" ON  analytics.api_pattern (verb);

CREATE INDEX "analytics_api_pattern_apipattern" ON  analytics.api_pattern (apipattern);
