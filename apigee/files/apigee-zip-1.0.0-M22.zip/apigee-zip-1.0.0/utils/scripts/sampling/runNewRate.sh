#!/bin/bash

. newRateConf.properties

org=$orgname;
env=$envname;
sampling_rate=$rate;
sampling_rate_word=$rateword;
start_time=$starttime;

echo 'Running historical sampling for $org:$env for rate $sampling_rate with word $sampling_rate_word from start time $start_time'

/usr/bin/sudo -u postgres /usr/pgsql-9.1/bin/psql -U postgres -d apigee  -c "select  analytics.new_sampling_rate_task('$org','$env',$sampling_rate,'$sampling_rate_word','$start_time')";

