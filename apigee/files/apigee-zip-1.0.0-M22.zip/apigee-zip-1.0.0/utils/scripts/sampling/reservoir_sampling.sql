--select  analytics.sampling_task('sampling','test',Array[.1,1,10],Array['PO','ONE','TEN'])
-- select analytics.new_sampling_rate_task('sampling','test',0.5,'PO5')

CREATE OR REPLACE FUNCTION analytics.reservoir_sampler(IN org text,IN env text,IN rate REAL,IN ratesAsWord TEXT,IN current_fact_partition TEXT,
					IN recordstarttime bigint,IN recordendtime bigint,IN last_sampled_time_val TIMESTAMP WITHOUT TIME ZONE,IN max_time_to_sample TIMESTAMP WITHOUT TIME ZONE,
					IN INCLUDE_START_TIME INT)
  RETURNS TIMESTAMP WITHOUT TIME ZONE AS
$BODY$
DECLARE
    MSG_COUNT_QUERY_TIME_LIMIT TEXT;
	FACT_COL_RECORD RECORD;
	CAPPED_UL_TIME TIMESTAMP WITHOUT TIME ZONE;
	CHILDTABLE_START_TIME TIMESTAMP WITHOUT TIME ZONE;
	CHILDTABLE_END_TIME TIMESTAMP WITHOUT TIME ZONE;
	TEMP_STR TEXT;
	TEMP_STR2 TEXT;
	TIME_CONSTRAINT TEXT;
	PARENT_SAMPLE_TABLE TEXT;
	TEMP_TABLE_NAME TEXT;
	SAMPLE_TABLE TEXT;
	FACT_PARTITION TEXT;
    AGG_TABLE TEXT;
	MAX_TIMESTAMP TIMESTAMP WITHOUT TIME ZONE;
	MSG_COUNT BIGINT;
	SAMPLING_SIZE INT;
	RECORD_POS INT[];  -- the positions we want to select to insert.
	RANDOM_NO INT;
	RECORD_POS_IN_VALUES TEXT := ''; -- the values to filter the row number of the records.
	FACT_COL TEXT; -- just a for variable
	FACT_COLUMNS TEXT := ''; -- all the current columns
	SAMPLE_SQL TEXT;
	CUSTOMER_IDENTIFIER TEXT;
	CUSTOMER_TABLE_PREFIX TEXT;
    FACT_COLS_AR TEXT[];
    SAMPLE_COLS_AR TEXT[];
    SMP_COL TEXT;
    SMP_MISSING_COLS_AR TEXT[];
    FACT_COL_TYPE TEXT;

	SMP_COL_TO_CREATE_AR TEXT[];
	SMP_TYPE_TO_CREATE_AR TEXT[];

    TEMP_VAL  INT;
    FOUND_COL boolean;
    START_TIME_BOUNDARY TEXT;
    BRANCHING_FACTOR INT;
    SMP_INDEX_NAME TEXT;
    PARTITION_NO INT;
    TEMP_CONTENT TEXT;


BEGIN

	RAISE NOTICE 'Found child table % % %',quote_ident(current_fact_partition),to_timestamp(recordstarttime/1000),to_timestamp(recordendtime/1000);

	CHILDTABLE_START_TIME := to_timestamp(recordstarttime/1000);
	CHILDTABLE_END_TIME := to_timestamp(recordendtime/1000);

	CUSTOMER_IDENTIFIER := org || '~' || env;
	CUSTOMER_TABLE_PREFIX := org || '.' || env || '.';

	FACT_PARTITION := 'analytics.' || '"' || current_fact_partition || '"' ;
    AGG_TABLE := 'analytics.' || '"' || CUSTOMER_TABLE_PREFIX || 'agg_app'|| '"';


    -- to ensure that sampling for current partition picks up valid records
	IF CHILDTABLE_START_TIME > last_sampled_time_val THEN
          last_sampled_time_val := CHILDTABLE_START_TIME;
          INCLUDE_START_TIME := 1;  -- include the time in sampling
	END IF;



	TEMP_STR := current_fact_partition;
	select substr(TEMP_STR,length(TEMP_STR) - strpos(reverse(TEMP_STR),'_') + 2) INTO TEMP_STR;

    PARTITION_NO := TEMP_STR;
	TEMP_STR := 'analytics.' || '"' || CUSTOMER_TABLE_PREFIX || 'smp_' || ratesAsWord || '_' || TEMP_STR || '"';
	SELECT  'check ( client_received_start_timestamp <' || quote_literal ( CHILDTABLE_END_TIME  )
			     || ' AND '||'  client_received_start_timestamp >= ' || quote_literal ( CHILDTABLE_START_TIME  )  || ')' INTO TIME_CONSTRAINT;
	SELECT  'analytics.'|| '"' || CUSTOMER_TABLE_PREFIX ||'smp_' || ratesAsWord ||'"' INTO PARENT_SAMPLE_TABLE;


    -- read the set of current columns in fact
    TEMP_VAL := 1;

    Execute ' CREATE TABLE IF NOT EXISTS ' ||  PARENT_SAMPLE_TABLE || ' ( like analytics."'  || CUSTOMER_TABLE_PREFIX || 'fact" including defaults)' ;


	Execute ' CREATE TABLE IF NOT EXISTS ' ||  TEMP_STR || ' ( '  || cast (TIME_CONSTRAINT as text)   || ' )  inherits  ( '|| PARENT_SAMPLE_TABLE ||')' ;
	SAMPLE_TABLE := TEMP_STR;

    -- INDEX on smp parition.



	execute 'select MAX(client_received_start_timestamp)   from '|| FACT_PARTITION into MAX_TIMESTAMP;

    if INCLUDE_START_TIME = 1 then
           START_TIME_BOUNDARY := ' where client_received_start_timestamp >= ' ||  quote_literal(last_sampled_time_val);
    else
           START_TIME_BOUNDARY := ' where client_received_start_timestamp > ' ||  quote_literal(last_sampled_time_val);
    end if;
   execute 'select MIN(client_received_start_timestamp)   from '|| FACT_PARTITION || ' where client_received_start_timestamp > ' ||  quote_literal(last_sampled_time_val) into CAPPED_UL_TIME;
   if CAPPED_UL_TIME < last_sampled_time_val + interval '30 minute' then
       CAPPED_UL_TIME := last_sampled_time_val + interval '30 minute';
   end if;
   MSG_COUNT_QUERY_TIME_LIMIT := START_TIME_BOUNDARY || ' and client_received_start_timestamp <= ' || quote_literal(CAPPED_UL_TIME);

    if MAX_TIMESTAMP is not null then
          -- make sure every rate is sampled to the same max time in fact
          if max_time_to_sample is not null then
             if MAX_TIMESTAMP > max_time_to_sample then
		         MAX_TIMESTAMP := max_time_to_sample;
                 raise notice 'reset MAX_TIMESTAMP found to be % org % env %',quote_literal(MAX_TIMESTAMP),org,env;
             end if;
          end if;
          execute 'select sum(message_count) from ' || AGG_TABLE
                          || ' where timestamp >= ' || quote_literal(last_sampled_time_val)
	                  ||' and timestamp <= '
				      || quote_literal(MAX_TIMESTAMP)
				      into MSG_COUNT;
         -- to cap the number of records to sample
        if MSG_COUNT > 120000 then
            raise notice 'MSG_COUNT_QUERY_TIME_LIMIT % org % env %',MSG_COUNT_QUERY_TIME_LIMIT,org,env;
            execute 'select max(client_received_start_timestamp) from (select client_received_start_timestamp from ' || FACT_PARTITION  || MSG_COUNT_QUERY_TIME_LIMIT || ' limit 120000) as SQ ' into MAX_TIMESTAMP;
            raise notice 'capped MAX_TIMESTAMP found to be % for org % env %',MAX_TIMESTAMP,org,env;
            MSG_COUNT = 121000;
        end if;

       SAMPLING_SIZE := round((rate * MSG_COUNT)/100);

       RAISE NOTICE 'sampling size for % from fact table % is %  where start time is % and end time is %',rate,FACT_PARTITION,SAMPLING_SIZE,quote_literal(last_sampled_time_val),quote_literal(MAX_TIMESTAMP);

       -- used to check if ideally no records satisfy the rate (if % was used instead).
       BRANCHING_FACTOR := SAMPLING_SIZE;

       raise notice 'BRANCHING_FACTOR % for rate %',BRANCHING_FACTOR,rate;

       -- Definitely at least records = rate is present
	   if BRANCHING_FACTOR >= 1 then

	 	    for counter in 1 .. SAMPLING_SIZE LOOP
	          RECORD_POS[counter] := counter;
        	END LOOP;


            for counter in SAMPLING_SIZE+1 .. MSG_COUNT LOOP
                  RANDOM_NO := floor(random() * counter);
                  if RANDOM_NO <= SAMPLING_SIZE  and RANDOM_NO > 0 then
                        RECORD_POS[RANDOM_NO] := counter;
                  end if;
            END LOOP;

           TEMP_CONTENT := '';
           for counter in array_lower(RECORD_POS,1) .. array_upper(RECORD_POS,1) loop
	         if counter < array_upper(RECORD_POS,1) then
		        RECORD_POS_IN_VALUES := RECORD_POS_IN_VALUES || RECORD_POS[counter] || ',';
		        TEMP_CONTENT := TEMP_CONTENT || '(' ||  RECORD_POS[counter] || ')' || ',';
		     else
		        RECORD_POS_IN_VALUES := RECORD_POS_IN_VALUES || RECORD_POS[counter];
		        TEMP_CONTENT := TEMP_CONTENT || '(' ||  RECORD_POS[counter] || ')';
		     end if;
	       end loop;


	       --select substr(RECORD_POS_IN_VALUES,1,(length(RECORD_POS_IN_VALUES) - strpos(reverse(RECORD_POS_IN_VALUES),',') )) into RECORD_POS_IN_VALUES;


	       FOR FACT_COL in select column_name from information_schema.columns where table_schema='analytics' and table_name = current_fact_partition
	        LOOP
		        FACT_COLUMNS := FACT_COLUMNS || FACT_COL || ',';
	         END LOOP;

	        select substr(FACT_COLUMNS,1,(length(FACT_COLUMNS) - strpos(reverse(FACT_COLUMNS),',') )) into FACT_COLUMNS;

            SELECT  CUSTOMER_TABLE_PREFIX ||'smp_' || ratesAsWord ||'_tmp' INTO TEMP_TABLE_NAME;

            TEMP_TABLE_NAME := replace(TEMP_TABLE_NAME,'.','_');


            execute 'CREATE TEMP TABLE ' || TEMP_TABLE_NAME || ' ( num BIGINT )';

            -- INDEX on temp table


            execute 'insert into ' || TEMP_TABLE_NAME || ' values '|| TEMP_CONTENT;


	        SAMPLE_SQL := 'insert into ' || SAMPLE_TABLE || '(' || FACT_COLUMNS || ') ( select ' || FACT_COLUMNS || ' from ( select ' || FACT_COLUMNS
					     || ', (row_number() OVER ()) as rn from analytics.' || '"' || CUSTOMER_TABLE_PREFIX || 'fact' || '"'
					     || START_TIME_BOUNDARY
					     || ' and client_received_start_timestamp <= ' || quote_literal(MAX_TIMESTAMP)
					     || ') ft inner join ' || TEMP_TABLE_NAME ||' tmpt on ft.rn = tmpt.num )';
           EXECUTE SAMPLE_SQL;
	        RAISE NOTICE ' INSERTED FOR  %', SAMPLE_TABLE;
	        execute 'DROP TABLE '|| TEMP_TABLE_NAME;
	        RETURN MAX_TIMESTAMP;

        -- DEFINITELY RECORDS < RATE
        elseif BRANCHING_FACTOR = 0 and MSG_COUNT > 0 then

             FOR FACT_COL in select column_name from information_schema.columns where table_schema='analytics' and table_name = current_fact_partition
             LOOP
                FACT_COLUMNS := FACT_COLUMNS || FACT_COL || ',';
             END LOOP;

             select substr(FACT_COLUMNS,1,(length(FACT_COLUMNS) - strpos(reverse(FACT_COLUMNS),',') )) into FACT_COLUMNS;
             SAMPLE_SQL := 'insert into ' || SAMPLE_TABLE || '(' || FACT_COLUMNS || ') ( select ' || FACT_COLUMNS || ' from ( select ' || FACT_COLUMNS
                                 || ', (row_number() OVER ()) as rn from analytics.' || '"' || CUSTOMER_TABLE_PREFIX || 'fact' || '"'
                                 || START_TIME_BOUNDARY
                                 || ' and client_received_start_timestamp <= ' || quote_literal(MAX_TIMESTAMP)
                                 || ') ft where ft.rn in (1) )';


             EXECUTE SAMPLE_SQL;
             RAISE NOTICE ' INSERTED FOR  %', SAMPLE_TABLE;
             RETURN MAX_TIMESTAMP;

        else
             RETURN NULL;

         end if; -- end of msg count >= and < cases

	else
	  raise notice 'no data yet in fact ..skip sampling for customer % with env %',org,env;
	  RETURN NULL;
	end if;


END;
$BODY$
LANGUAGE plpgsql




