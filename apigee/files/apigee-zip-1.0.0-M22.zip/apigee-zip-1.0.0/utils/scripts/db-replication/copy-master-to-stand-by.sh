#/bin/sh -x

#
# This script copies the data from master PG to stand-by PG server
#
# If the master PG is running, it will pg_start_backup first, rsync the PG data directory and pg_stop_backup.
# If the master PG is _not_ running, it will just do rsync
#

# Please change the following variables to point to appropriate PG directories.
# Note: The PG directoties must be existing and should be owned by 'postgres' user.

PORT=5432
SOURCE_CLUSTER=/ebs/pgdata
DEST_CLUSTER=/ebs/pgdata

# Apart from the above variables, you don't have to change any other stuff below.

function postgres_status()
{
        # Search Postgres postmaster process ID
        ps -ef | grep [p]ostmaster > /dev/null 2>&1;
        if [ $? -eq 0 ]; then
                echo "RUNNING";
        else
                echo "NOT-RUNNING";
        fi
}

function cleanup()
{
        if [ ${backup_in_progress} -eq 1 ]; then
                end_pg_backup;
        fi

        echo "Cleaned up. Exiting.";

        exit 2;
}

function exit_if_error()
{
        status=$1;
        errMsg=$2;

        if [ ${status} -ne 0 ]; then
                echo ""; # Blank line
                echo "ERROR: ${errMsg}";

                # cleanup - and it will exit
                cleanup;
        fi

}

function begin_pg_backup()
{
        echo "Executing pg_start_backup() ... ";

        psql  -U postgres -p $PORT \
                -c "SELECT pg_start_backup('Streaming Replication', true)" postgres;

        status=$?;

        exit_if_error ${status} "pg_start_backup() failed. Exiting";

        backup_in_progress=1;

        echo "Done";
}

function end_pg_backup()
{
        echo "Executing pg_stop_backup() ... ";

        psql   -U postgres -p $PORT -c "SELECT pg_stop_backup()" postgres;

        status=$?;

        exit_if_error ${status} "pg_stop_backup() failed. Exiting";

        echo "Done";
}

# main

if [ $# -lt 2 ]
then
        echo "Usage: $0 <localserver-internal-hostname> <remote-server-internal-hostname>"
        echo "";
        echo "  Description: This script backs up PG data directory from Master to Stand-by.";
        echo "  Note: This script must be run from the Master PG machine";
        exit 1;
fi

# Trap signals so that we can cleanup
trap 'echo "Signal caught ... "; cleanup' SIGINT SIGQUIT SIGTERM;

primary_ip=$1
remote_ip=$2

backup_in_progress=0;

dt=`date`;
echo "----------- ${dt}: START - $0 -----------";

pg_status=`postgres_status`;

if [ ${pg_status} == "RUNNING" ]; then
        begin_pg_backup;
fi

echo "Syncing ${primary_ip}:$SOURCE_CLUSTER/ to ${remote_ip}:$DEST_CLUSTER/ ...";

rsync  -a $SOURCE_CLUSTER/ postgres@$remote_ip:$DEST_CLUSTER/ --exclude trigger_file --exclude pg_hba.conf --exclude postmaster.pid --exclude recovery.done --exclude recovery.conf

# rsync may return error on partial copy. Hence, ignoring for time being.
#status=$?
#exit_if_error ${status} "rsync failed. Exiting";

echo "Done";

ssh -o stricthostkeychecking=no  postgres@$remote_ip  rm -f $DEST_CLUSTER/recovery.done
ssh -o stricthostkeychecking=no  postgres@$remote_ip  rm -f $DEST_CLUSTER/trigger_file

echo "Creating recovery.conf at ${remote_ip}:$DEST_CLUSTER/ ...";

ssh  -o stricthostkeychecking=no postgres@$remote_ip \
        cp  $DEST_CLUSTER/recovery_conf.txt  $DEST_CLUSTER/recovery.conf

ssh  -o stricthostkeychecking=no postgres@$remote_ip \
        sed -i.bak "s/primaryserverinternalhostname/$primary_ip/g"  $DEST_CLUSTER/recovery.conf

status=$?

exit_if_error ${status} "Creation of recovery.conf failed. Exiting";

echo "Done";

if [ ${pg_status} == "RUNNING" ]; then
        end_pg_backup;
fi

dt=`date`;
echo "----------- ${dt}: END - $0 -----------";

echo "Toggling ${remote_ip}  pg-agent to standby ";
# curl -v http://${remote_ip}:8080/v1/servers/self/state -d STANDBY -H "Content-Type: application/json"
ssh  -o stricthostkeychecking=no postgres@$remote_ip /etc/init.d/apigee-pg restart;
exit 0;
