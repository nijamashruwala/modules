#/bin/sh -x

#
# This script promotes the stand-by PG to master.
#
# Note: This script MUST be executed on the PG stand-by machine
#
# The script 'tries' to do rsync from master to stand-by before promoting.
#

SSH_PORT=22

SOURCE_CLUSTER=/ebs/pgdata
DEST_CLUSTER=/ebs/pgdata

# Check whether the machine is reachable by pinging SSH port
# We are making use of 'nc' to ping a particular port

function is_machine_reachable()
{
        host=$1;

        # Wait for 2 seconds only
        nc -w 2 -z ${host} ${SSH_PORT} > /dev/null 2>&1
        status=$?

        if [ ${status} -eq 0 ]; then
                echo "RUNNING";
        else
                echo "NOT-RUNNING";
        fi
}

# main

if [ $# -lt 1 ]; then
        echo "Usage: $0 <master-server-internal-hostname>"
        exit 1
fi

master_server=$1

TRIGGER_FILE=${DEST_CLUSTER}/trigger_file

# If the master is reachable, then do a rsync from master to stand-by before promoting.

pg_status=`is_machine_reachable ${master_server}`;

if [ ${pg_status} == "RUNNING" ]; then

        echo "rsync from ${master_server}:$SOURCE_CLUSTER/ to $DEST_CLUSTER/ ...";

        rsync -a postgres@${master_server}:$SOURCE_CLUSTER/ $DEST_CLUSTER/ --exclude trigger_file --exclude pg_hba.conf \
                --exclude postmaster.pid --exclude recovery.done --exclude recovery.conf

        echo "Done";
else
        echo "WARN: ${master_server} not reachable. rsync not done";
fi

# Create the trigger file
# This promotes the PG stand-by to master

echo "Creating the trigger file ${TRIGGER_FILE} to promote this stand-by to master ...";

touch ${TRIGGER_FILE}

remote_ip=$master_server
echo "Toggling ${master_server} pg-agent to standby ";
#curl -v http://${master_server}:8080/v1/servers/self/state -d STANDBY -H "Content-Type: application/json"
ssh -o stricthostkeychecking=no postgres@$remote_ip /etc/init.d/apigee-pg restart;
echo "Toggling localhost  pg-agent to ACTIVE ";
#curl -v http://localhost:8080/v1/servers/self/state -d ACTIVE -H "Content-Type: application/json"
/etc/init.d/apigee-pg restart;

echo "Done"

exit 0;
